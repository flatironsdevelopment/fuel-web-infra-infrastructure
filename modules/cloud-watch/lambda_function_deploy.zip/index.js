
exports.handler = async (event, context) => {
  try {
      console.log(event);
      const ecsEvent = event.detail || {};
      const resourceArn = event.resources?.[0] || '';
      const resourceParts = resourceArn.split('/'); 

      const clusterArn = ecsEvent.clusterArn || '';
      
      // Extract names from arn
      const serviceName = resourceArn.split('/').pop() || 'unknown-service';
      const clusterName = resourceParts[resourceParts.length - 2] || 'unknown-cluster';
      
      const isFailure = ecsEvent.eventName === 'SERVICE_DEPLOYMENT_FAILED';
      const status = isFailure ? 'FAILED 🚨' : 'SUCCESS ✅';
      const color = isFailure ? '#ff0000' : '#36a64f';
      
      // Message Structure
      const slackMessage = {
          text: `${isFailure ? '🚨' : '✅'} *ECS Deployment Alert*`,
          attachments: [{
              color: color,
              fields: [
                  { title: 'Service', value: serviceName, short: true },
                  { title: 'Cluster', value: clusterName, short: true },
                  { title: 'Status', value: status, short: true },
                  { title: 'Reason', value: ecsEvent.reason || 'No reason provided', short: false },
                  { title: 'Time', value: new Date(event.time).toUTCString(), short: false }
              ],
              footer: `Event ID: ${event.id}`
          }]
      };

      const response = await fetch(process.env.SLACK_WEBHOOK_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(slackMessage)
      });
      
      const result = await response.text();

      return {
          statusCode: 200,
          body: result
      };
      
  } catch (error) {
      console.error('Error when processing event', error);
      throw error;
  }
};
