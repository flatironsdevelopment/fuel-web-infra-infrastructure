import os
import json
import urllib.request

def lambda_handler(event, context):
    slack_webhook_url = os.getenv('SLACK_WEBHOOK_URL')

    message = json.loads(event['Records'][0]['Sns']['Message'])

    slack_message = {
        "text": f"Alarm Name: {message['AlarmName']}\n"
                f"Alarm Description: {message['AlarmDescription']}\n"
                f"AWS Account: {message['AWSAccountId']}\n"
                f"Region: {message['Region']}\n"
                f"Reason: {message['NewStateReason']}\n"
                f"State Change: {message['OldStateValue']} -> {message['NewStateValue']}"
    }

    req = urllib.request.Request(slack_webhook_url, data=json.dumps(slack_message).encode(), headers={'Content-Type': 'application/json'})
    response = urllib.request.urlopen(req)
    return response.read()
